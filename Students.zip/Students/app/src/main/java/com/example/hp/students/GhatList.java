package com.example.hp.students;

public class GhatList {

    private String stuName;
    private String stuAddress;
    private String stuEmail;
    private String stuPhone;



    private int mImageResourceId;
    public GhatList(String sName, String sAddress,String sEmail, String sPhone, int imageResourceId)
    {
        stuName = sName;
        stuAddress = sAddress;
        stuEmail = sEmail;
        stuPhone = sPhone;
        mImageResourceId = imageResourceId;
    }

    public String getVersionName() {
        return stuName;
    }
    public String getVersionAddress() {
        return stuAddress;
    }
    public String getVersionEmail() {
        return stuEmail;
    }
    public String getVersionPhone() {
        return stuPhone;
    }

    public int getImageResourceId() {
        return mImageResourceId;
    }

}
