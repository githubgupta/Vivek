package com.example.hp.students;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class AddStudent extends AppCompatActivity {

    MyHelper helper = new MyHelper(this);
    Context ctx = this;
    Button asb1, asb2, asb3, asb4, asb5, asb6;
    EditText et1, et2, et3, et4;
    ImageView iv;
    final int TAKE_PICTURE = 1;
    final int ACTIVITY_SELECT_IMAGE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        asb1 = (Button) findViewById(R.id.upload);

        asb2 = (Button) findViewById(R.id.addstudent);
        asb3 = (Button) findViewById(R.id.viewstudent);
        asb4 = (Button) findViewById(R.id.updatestudent);
        asb5 = (Button) findViewById(R.id.deletestudent);
        asb6 = (Button) findViewById(R.id.nxtpage);

        et1 = (EditText) findViewById(R.id.stu_edit1);
        et2 = (EditText) findViewById(R.id.stu_edit2);
        et3 = (EditText) findViewById(R.id.stu_edit3);
        et4 = (EditText) findViewById(R.id.stu_edit4);

        iv = (ImageView) findViewById(R.id.stuPicUpload);

        AddData();
        viewAll();
        UpdateData();
        DeleteData();

        asb6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(getApplicationContext(), Home.class);
                startActivity(intent);
                Toast.makeText(getBaseContext(), "Please wait", Toast.LENGTH_LONG).show();
            }
        });

    }

    public void AddData() {
        asb2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        final String email;
                        final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                        String name, phone, address;

                        name = et1.getText().toString();
                        if (TextUtils.isEmpty(name) || name.length() < 5) {
                            et1.setError("Please ! Enter Atleast 5 Characters.");
                            return;
                        }

                        address = et2.getText().toString();
                        if (TextUtils.isEmpty(address) || address.length() < 10) {
                            et2.setError("Please ! Enter Atleast 10 Characters.");
                            return;
                        }
                        email = et3.getText().toString().trim();

                        phone = et4.getText().toString();
                        if (TextUtils.isEmpty(phone) || phone.length() < 10) {
                            et4.setError("Please ! Enter A 10 Digit Valid Mobile No.");
                            return;
                        }

                        if (name.equals("") || email.equals("") || phone.equals("") || address.equals("")) {
                            Toast.makeText(getApplicationContext(), "All fields should be filled correctly.", Toast.LENGTH_LONG).show();
                            return;
                        }

                        if (email.matches(emailPattern) && email.length() > 0) {

                            File filename;
                            BitmapDrawable drawable = (BitmapDrawable) iv.getDrawable();
                            Bitmap bitmap = drawable.getBitmap();
                            try {
                                String path = Environment.getExternalStorageDirectory().toString();
                                new File(path + "/folder/students").mkdirs();
                                filename = new File(path + "/folder/students/" + (et1.getText().toString()) + ".jpg");
                                FileOutputStream out = new FileOutputStream(filename);

                                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);

                                out.flush();
                                out.close();

                                MediaStore.Images.Media.insertImage(getContentResolver(), filename.getAbsolutePath(), filename.getName(), filename.getName());
                            } catch (Exception e) {
                                e.printStackTrace();

                            }
                            boolean isInserted = helper.insertData(name, address, email, phone);
                            if (isInserted == true)

                                Toast.makeText(AddStudent.this, "Student Added Successfully !", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(AddStudent.this, "Invalid Email ID !", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void viewAll() {
        asb3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = helper.getAllData();
                        if (res.getCount() == 0) {
                            // show message
                            showMessage("Error", "Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Name :" + res.getString(0) + "\n");
                            buffer.append("Address :" + res.getString(1) + "\n");
                            buffer.append("Email :" + res.getString(2) + "\n");
                            buffer.append("Phone :" + res.getString(3) + "\n\n");
                        }

                        // Show all data
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }


    public void UpdateData() {
        asb4.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = helper.updateData(et4.getText().toString(),
                                et1.getText().toString(),
                                et2.getText().toString(), et3.getText().toString());
                        if (isUpdate == true)
                            Toast.makeText(AddStudent.this, "Data Update", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(AddStudent.this, "Data not Updated", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void DeleteData() {
        asb5.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = helper.deleteData(et4.getText().toString());
                        if (deletedRows > 0)
                            Toast.makeText(AddStudent.this, "Data Deleted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(AddStudent.this, "Data not Deleted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }


    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void fun(View v) {
        selectImage();
    }

    public void selectImage() {
        final CharSequence[] options = {"Take Photo", "Choose From Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(AddStudent.this);
        builder.setTitle("Choose Option !");

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                if (options[which].equals("Take Photo")) {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, TAKE_PICTURE);
                } else if (options[which].equals("Choose From Gallery")) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, ACTIVITY_SELECT_IMAGE);
                } else if (options[which].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    @SuppressWarnings("deprecation")
    public void onActivityResult(int requestcode, int resultcode, Intent intent) {
        super.onActivityResult(requestcode, resultcode, intent);
        if (resultcode == RESULT_OK) {
            if (requestcode == TAKE_PICTURE) {

                Bitmap photo = (Bitmap) intent.getExtras().get("data");
                Drawable drawable = new BitmapDrawable(photo);
                iv.setImageDrawable(drawable);

            } else if (requestcode == ACTIVITY_SELECT_IMAGE) {
                Uri selectedImage = intent.getData();
                String[] filePath = {MediaStore.Images.Media.DATA};
                Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                Drawable drawable = new BitmapDrawable(thumbnail);
                iv.setImageDrawable(drawable);

            }
        }
    }
}
