package com.example.hp.students;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;

public class StudentProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);

        Bundle b = getIntent().getExtras();

        TextView nme = (TextView) findViewById(R.id.stuName);
        TextView adr = (TextView) findViewById(R.id.stuAddres);
        TextView eml = (TextView) findViewById(R.id.stuEmail);
        TextView phn = (TextView) findViewById(R.id.stuPhone);
        ImageView iv=(ImageView)findViewById(R.id.stuPic);
        Button spb1 = (Button)findViewById(R.id.goHome);

        spb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(StudentProfile.this, Ghat.class);
                startActivity(i);
            }
        });


     /*   nme.setText(b.getCharSequence("name"));
        eml.setText(b.getCharSequence("email"));
        adr.setText(b.getCharSequence("address"));
        phn.setText(b.getCharSequence("phone"));*/
/*
        String path = Environment.getExternalStorageDirectory().toString();
        File f = new File(path + "/folder/students/"+nme.getText().toString()+".jpg");
        Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
        iv.setImageBitmap(bmp);

*/
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.guest, menu);
        return true;
    }
*/

}

